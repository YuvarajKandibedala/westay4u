import { RoomOption, Amenity, Testimonial, FAQ, University } from "./types";

export const UNIVERSITIES: University[] = [
  {
    name: "Amity University Bengaluru",
    distanceKm: 1.2,
    autoMinutes: 3,
    walkMinutes: 8,
    logoUrl: "https://images.unsplash.com/photo-1592280771190-3e2e4d571952?auto=format&fit=crop&q=80&w=150"
  },
  {
    name: "GITAM University Bengaluru",
    distanceKm: 1.5,
    autoMinutes: 4,
    walkMinutes: 11,
    logoUrl: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=150"
  }
];

export const ROOMS: RoomOption[] = [
  {
    id: "room-single",
    name: "Presidential Single Suite",
    sharingLevel: "Single",
    pricePerMonth: 18000,
    image: "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&q=80&w=800",
    tagline: "Ultra Premium Personal Comfort",
    description: "Features a modern spacious study desk, direct ergonomic chair, a king-single posture-pedic mattress, dual wardrobes, premium split AC, and an attached modern washroom. Ideal for students focused on coding, deep study, and individual tranquility.",
    features: ["Attached washroom", "Personal Split AC", "Premium Ergo Desk", "Smart Storage", "Individual Fridge"]
  },
  {
    id: "room-double",
    name: "Classic Co-Living Double",
    sharingLevel: "Double",
    pricePerMonth: 12000,
    image: "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&q=80&w=800",
    tagline: "Balanced Shared Student Joy",
    description: "The sweet spot of student budget and premium company. Dual individualized study desks aligned to the windows, separate tall closets, comfy orthopedic twin beds, and an ensuite modern bathroom. Share with one neat classmate.",
    features: ["Dual study tables", "Ensuite washroom", "Individual lockers", "High-speed Ethernet drop", "Balcony access"]
  },
  {
    id: "room-triple",
    name: "Modern Buddy Triple sharing",
    sharingLevel: "Triple",
    pricePerMonth: 9000,
    image: "https://images.unsplash.com/photo-1555854877-abab0e164eaf?auto=format&fit=crop&q=80&w=800",
    tagline: "Community Centred Value Stay",
    description: "Ultimate student community experience at a smart pocket-friendly flat-rate. Smartly optimized spaces with three modular beds, dedicated study carrels, generous biometric safe lockers, and attached washrooms. Best value in town.",
    features: ["Personal safe lockers", "Optimized space layout", "Three separate dressers", "Full ventilation", "All-inclusive maintenance"]
  }
];

export const AMENITIES: Amenity[] = [
  {
    id: "amenity-wifi",
    name: "200 Mbps Fiber Wi-Fi",
    category: "Essential",
    iconName: "Wifi",
    description: "Dual-carrier low-latency internet with 100% router density in corridors for smooth online lectures, coding sprints and competitive gaming."
  },
  {
    id: "amenity-meals",
    name: "Four 5-Star Guided Meals",
    category: "Hygie-Wellness",
    iconName: "ChefHat",
    description: "Breakfast, Lunch, Hi-Tea, and Dinner. Chef-prepared meals combining North & South Indian preferences. 100% fresh, hygienic, and health-checked ingredients."
  },
  {
    id: "amenity-security",
    name: "Ironclad 24/7 Shielding",
    category: "Essential",
    iconName: "ShieldCheck",
    description: "Biometric face-scans, 24/7 CCTV vigilance, and onsite female & male wardens. Zero entry for outsiders without dual verification."
  },
  {
    id: "amenity-shuttle",
    name: "Free Regular Campus Shuttles",
    category: "Premium-Lifestyle",
    iconName: "Car",
    description: "Regular pickup and drop services straight to the gates of Amity University and GITAM University every 15 minutes during campus hours."
  },
  {
    id: "amenity-backup",
    name: "100% Uninterrupted Power",
    category: "Essential",
    iconName: "Zap",
    description: "Heavy diesel silent-generators switch on in under 3 seconds to keep fans, lights, dynamic routers, and safety biometrics powered up all semester."
  },
  {
    id: "amenity-laundry",
    name: "Professional Dual Laundry",
    category: "Hygie-Wellness",
    iconName: "FlameKindling", // Representing clothing care or dry heat laundry
    description: "Complimentary twice-a-week mechanized laundry and hot steam ironing. Your clothes are picked up and delivered right to your wardrobe doors."
  },
  {
    id: "amenity-recreational",
    name: "Vibrant Gaming & Study Common Zones",
    category: "Premium-Lifestyle",
    iconName: "Gamepad2",
    description: "Includes Game lounge with PS5 and foosball tables, plus quiet, soundproof pods for deep focus work or mock exams."
  },
  {
    id: "amenity-housekeeping",
    name: "Daily Janitorial Housekeeping",
    category: "Hygie-Wellness",
    iconName: "Sparkles",
    description: "Daily room sweeping, waste collection, and meticulous weekly deep sanitization of all washrooms by professional services."
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "test-1",
    author: "Ayush Saxena",
    role: "Student",
    relationDetails: "Amity Bengaluru - B.Tech CSE (Year 2)",
    quote: "Living at WeStay4U is an absolute breeze. The complimentary shuttle is a lifesaver when I have 9 AM labs at Amity, and the 200 Mbps Wi-Fi lets me run high-level machine learning models with zero delays. The food tastes just like my home in Delhi!",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=120"
  },
  {
    id: "test-2",
    author: "Mrs. Revathi Swaminathan",
    role: "Parent",
    relationDetails: "Mother of Shreya, GITAM Biotech Student",
    quote: "As a parent from Chennai, safety was my topmost priority for my only daughter in Bengaluru. WeStay4U has biometric gates, corridor surveillance, and active lady wardens always available on call. The 4 daily nutritious meals completely put my dietary worries to rest.",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=120"
  },
  {
    id: "test-3",
    author: "Vikram Sengupta",
    role: "Student",
    relationDetails: "GITAM University - MBA Professional",
    quote: "The 4-years package locked in my pricing and protected me from the rents rising near college. The shared gaming lounge with PS5 is where our team relaxes after massive case study presentations. Highly recommended premium lifestyle choice!",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=120"
  }
];

export const FAQS: FAQ[] = [
  {
    id: "faq-1",
    question: "Is high-quality, nutritious food included in the monthly rent package?",
    answer: "Absolutely! There are no sneaky extra fees. Your package contains 4 carefully curated meals every single day (Breakfast, Lunch, Hi-Tea, and Dinner) featuring customizable North Indian and South Indian menus prepared under ISO-certified kitchen standards.",
    category: "Amenities"
  },
  {
    id: "faq-2",
    question: "How frequent is the complimentary campus shuttle service?",
    answer: "Our shuttles transport WeStay4U residents straight to the gates of both Amity University Bengaluru and GITAM University. Shuttles depart every 15 minutes starting at 8:00 AM and run until 6:00 PM, plus we offer special night services for library study rounds.",
    category: "Location"
  },
  {
    id: "faq-3",
    question: "What solid security features are in place for students, especially girls?",
    answer: "Security is non-negotiable. We features restricted biometric facial recognition locks at the entrance, 24/7 CCTV recording for all entries/exits/corridors, dedicated professional wardens physically living inside, and a hard lock on outside male/female visitors past 8:00 PM.",
    category: "Parent Comfort"
  },
  {
    id: "faq-4",
    question: "Does the rooms have 100% power backup?",
    answer: "Yes, our properties feature silent high-yield standby diesel generator units. They automatically ignite within 3 seconds of grid load outages to preserve continuous power for your lights, cooling devices, common lift shafts, and internet routers.",
    category: "Amenities"
  },
  {
    id: "faq-5",
    question: "How does the '4 Years. Zero Worries.' Degree-Stay Package work?",
    answer: "Rental rates in Bengaluru normally escalate by 10-15% annually. Our flagship 4-Year plan locks your initial rent for your entire college stay! You are shielded completely against local pricing spikes, and receive absolute priority on room selections, free premium examination laundry, and priority check-in.",
    category: "Billing"
  },
  {
    id: "faq-6",
    question: "Is there a washing machine, or is laundry outsourced?",
    answer: "We offer professional laundry services. Students simply drop off their clothes in personalized hampers twice a week, which are clean-washed, disinfected, hot-steam ironed, and neatly returned to their doors within 48 hours for free.",
    category: "Amenities"
  }
];

export const GALLERY: { url: string; category: string; description: string }[] = [
  {
    url: "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&q=80&w=800",
    category: "Bedrooms",
    description: "Premium study layout with individual high-focus desks"
  },
  {
    url: "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&q=80&w=800",
    category: "Bedrooms",
    description: "Spacious dual-sharing beds with dedicated personal side tables"
  },
  {
    url: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=800",
    category: "Study Areas",
    description: "Sound-isolated coding library and personal exam study pods"
  },
  {
    url: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&q=80&w=800",
    category: "Food & Dining",
    description: "Multi-cuisine, chef-curated premium dining plates cooked fresh"
  },
  {
    url: "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&q=80&w=800",
    category: "Common Spaces",
    description: "Leisure lounge with game consoles, comfortable beanbags, and foosball"
  },
  {
    url: "https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?auto=format&fit=crop&q=80&w=800",
    category: "Washrooms",
    description: "Spotless modular washrooms deep-sanitized daily"
  }
];
