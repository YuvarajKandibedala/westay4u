import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Phone,
  MessageSquare,
  Sparkles,
  Wifi,
  ShieldCheck,
  ChefHat,
  Car,
  Zap,
  Gamepad2,
  Star,
  ChevronDown,
  Building,
  GraduationCap,
  Lock,
  Clock,
  MapPin,
  ExternalLink,
  ChevronRight,
  ShieldAlert,
  Sliders,
  Menu,
  X,
  Heart,
  Calendar,
  CheckCircle,
  DollarSign
} from "lucide-react";

import { RoomOption, SharingLevel, Lead } from "./types";
import { UNIVERSITIES, ROOMS, AMENITIES, TESTIMONIALS, FAQS, GALLERY } from "./data";

// Import modular panels/popups
import ChatBot from "./components/ChatBot";
import InteractiveCalculator from "./components/InteractiveCalculator";
import LeadPopup from "./components/LeadPopup";
import AdminPanel from "./components/AdminPanel";

export default function App() {
  // Navigation / Drawer state
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [updateTrigger, setUpdateTrigger] = useState(0);

  // Leads form state
  const [leadName, setLeadName] = useState("");
  const [leadPhone, setLeadPhone] = useState("");
  const [leadUni, setLeadUni] = useState("Amity University Bengaluru");
  const [leadStay, setLeadStay] = useState("Degree-Stay Plan (4 Years locked)");
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [formSuccess, setFormSuccess] = useState(false);
  const [formError, setFormError] = useState("");

  // Gallery active filters
  const [activeGalleryTab, setActiveGalleryTab] = useState("All");

  // FAQ active state
  const [activeFaqId, setActiveFaqId] = useState<string | null>("faq-1");

  // Auto-filled calculator states
  const [selectedConfigLabel, setSelectedConfigLabel] = useState<string | null>(null);

  // References to scroll targets
  const calculatorRef = useRef<HTMLDivElement>(null);
  const contactFormRef = useRef<HTMLDivElement>(null);
  const roomsRef = useRef<HTMLDivElement>(null);

  const scrollToSection = (elementRef: React.RefObject<HTMLDivElement | null>) => {
    if (elementRef.current) {
      elementRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  // Pre-fill fields from Interactive Calculator selections
  const handlePreSelectConfig = (config: {
    roomType: string;
    preferredStay: string;
    finalPrice: number;
  }) => {
    setLeadStay(`${config.roomType} (${config.preferredStay})`);
    setSelectedConfigLabel(`Applied Config: ${config.roomType} share - Estimated ₹${config.finalPrice.toLocaleString()}/month`);
    
    // Smoothly scroll down to the bottom form
    scrollToSection(contactFormRef);
    
    // Focus the name field
    const nameInput = document.getElementById("lead-form-name");
    if (nameInput) {
      setTimeout(() => nameInput.focus(), 800);
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leadName.trim() || !leadPhone.trim()) {
      setFormError("Student Name and Phone Number are mandatory to book stays.");
      return;
    }

    setFormSubmitting(true);
    setFormError("");

    try {
      const response = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: leadName,
          phone: leadPhone,
          university: leadUni,
          preferredStay: leadStay
        })
      });

      if (response.ok) {
        setFormSuccess(true);
        // Clear fields
        setLeadName("");
        setLeadPhone("");
        // Notify any admin board leads re-render
        setUpdateTrigger((prev) => prev + 1);
      } else {
        setFormError("Server refused submission. Please contact +91 9121936522 straight away.");
      }
    } catch (err) {
      setFormError("Network failure. Please verify connection and try again.");
    } finally {
      setFormSubmitting(false);
    }
  };

  // Filtered gallery tabs
  const galleryTabs = ["All", "Bedrooms", "Study Areas", "Food & Dining", "Common Spaces", "Washrooms"];
  const filteredGallery = activeGalleryTab === "All"
    ? GALLERY
    : GALLERY.filter((item) => item.category === activeGalleryTab);

  // Get matching icon for amenities
  const getAmenityIcon = (iconName: string) => {
    switch (iconName) {
      case "Wifi": return <Wifi className="h-6 w-6 text-brand-yellow" />;
      case "ChefHat": return <ChefHat className="h-6 w-6 text-brand-yellow" />;
      case "ShieldCheck": return <ShieldCheck className="h-6 w-6 text-brand-yellow" />;
      case "Car": return <Car className="h-6 w-6 text-brand-yellow" />;
      case "Zap": return <Zap className="h-6 w-6 text-brand-yellow" />;
      case "Gamepad2": return <Gamepad2 className="h-6 w-6 text-brand-yellow" />;
      default: return <Sparkles className="h-6 w-6 text-brand-yellow" />;
    }
  };

  return (
    <div className="min-h-screen bg-brand-blue font-sans text-gray-200 antialiased selection:bg-brand-yellow selection:text-brand-blue">
      
      {/* 20 seconds lead popup element */}
      <LeadPopup />

      {/* Persistent floating conversion calls/whatsapp for student action */}
      <div className="fixed bottom-6 left-6 z-40 flex flex-col gap-3">
        {/* Floating Call adviser link */}
        <a
          id="floating-call-btn"
          href="tel:+919121936522"
          className="flex h-12 items-center gap-2.5 rounded-full bg-brand-yellow px-4.5 text-xs font-bold text-brand-blue shadow-2xl hover:bg-brand-yellow-hover transition-transform hover:-translate-y-0.5 focus:outline-none"
        >
          <Phone className="h-4 w-4 fill-brand-blue" />
          <span className="hidden sm:inline font-mono tracking-wide">+91 9121936522</span>
          <span className="inline sm:hidden">Call Now</span>
        </a>

        {/* Floating WhatsApp chat link */}
        <a
          id="floating-whatsapp-btn"
          href="https://wa.me/919121936522?text=Hello%20WeStay4U,%20I%20am%20interested%20in%20knowing%20more%20about%20your%20premium%20student%20accommodations%20near%20Amity%20/%20GITAM!"
          target="_blank"
          rel="noopener noreferrer"
          className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500 text-white shadow-2xl hover:bg-emerald-600 transition-transform hover:-translate-y-0.5"
        >
          <MessageSquare className="h-5 w-5 fill-white" />
        </a>
      </div>

      {/* Gemini dialog Guru floating in bottom corner */}
      <ChatBot />

      {/* Header element */}
      <header className="sticky top-0 z-30 border-b border-zinc-800 bg-[#09090b]/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 md:px-8">
          
          {/* Brand Logo and descriptor - Bento Grid style */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
            <div className="flex h-8 w-8 bg-[#fafafa] items-center justify-center rounded-xs shadow-inner">
              <span className="text-[#09090b] font-display font-extrabold text-xs tracking-tighter">WS</span>
            </div>
            <div>
              <span className="font-display text-sm font-bold tracking-tight text-white uppercase underline underline-offset-4 decoration-zinc-700 block">
                WESTAY4U // STUDIO
              </span>
              <span className="text-[9px] text-zinc-500 font-mono tracking-widest block uppercase mt-0.5">Premium Student Living</span>
            </div>
          </div>

          {/* Desktop Navigation - High contrast Bento theme */}
          <nav className="hidden lg:flex items-center gap-7 text-[11px] font-mono font-medium uppercase tracking-wider text-zinc-400">
            <button onClick={() => scrollToSection(roomsRef)} className="hover:text-white transition-colors cursor-pointer">Stays</button>
            <a href="#why-choose" className="hover:text-white transition-colors">Why WeStay</a>
            <a href="#universities" className="hover:text-white transition-colors">Locations</a>
            <button onClick={() => scrollToSection(calculatorRef)} className="hover:text-white transition-colors cursor-pointer">Configurator</button>
            <a href="#amenities" className="hover:text-white transition-colors">Amenities</a>
            <a href="#gallery" className="hover:text-white transition-colors">Gallery</a>
            <a href="#faqs" className="hover:text-white transition-colors">FAQs</a>
          </nav>

          {/* Admin Toggle button & Book CTAs */}
          <div className="flex items-center gap-3">
            {/* Version and Date tag from Bento Theme */}
            <div className="hidden xl:block text-[10px] text-zinc-500 font-mono mr-2">
              V_2.06 // 2026
            </div>

            {/* Secures live insights on leads submitting */}
            <button
              id="admin-board-toggle"
              onClick={() => setIsAdminOpen(!isAdminOpen)}
              className={`hidden md:flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-[10px] font-mono font-medium tracking-tight transition-all cursor-pointer ${
                isAdminOpen
                  ? "border-brand-yellow bg-brand-yellow/10 text-brand-yellow"
                  : "border-zinc-800 bg-zinc-900/50 text-zinc-400 hover:text-white hover:border-zinc-700"
              }`}
            >
              <Sliders className="h-3.5 w-3.5" />
              {isAdminOpen ? "Close CRM Board" : "🧑‍💼 Advisor Panel"}
            </button>

            <button
              onClick={() => scrollToSection(contactFormRef)}
              className="rounded-lg bg-[#fafafa] border border-zinc-800 px-4.5 py-2 text-xs font-bold text-[#09090b] transition-all hover:bg-zinc-200 shadow-md cursor-pointer"
            >
              Book Stays
            </button>

            {/* Mobile Drawer Trigger icon */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-1.5 bg-zinc-900 rounded border border-zinc-800 text-zinc-400 hover:text-white"
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile menu drawer */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden border-t border-white/5 bg-brand-blue-light/95 px-4 py-4.5 space-y-4 text-sm font-semibold tracking-wide"
            >
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  scrollToSection(roomsRef);
                }}
                className="block text-left w-full hover:text-brand-yellow py-1 text-gray-300"
              >
                Room Options
              </button>
              <a
                href="#why-choose"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block hover:text-brand-yellow py-1 text-gray-300"
              >
                Why WeStay
              </a>
              <a
                href="#universities"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block hover:text-brand-yellow py-1 text-gray-300"
              >
                Nearby Universities
              </a>
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  scrollToSection(calculatorRef);
                }}
                className="block text-left w-full hover:text-brand-yellow py-1 text-gray-300"
              >
                Cost Estimator Configurator
              </button>
              <a
                href="#amenities"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block hover:text-brand-yellow py-1 text-gray-300"
              >
                Amenities Catalog
              </a>
              <a
                href="#gallery"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block hover:text-brand-yellow py-1 text-gray-300"
              >
                Lifestyle Gallery
              </a>
              <a
                href="#faqs"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block hover:text-brand-yellow py-1 text-gray-300"
              >
                Frequently Asked Query
              </a>

              <div className="pt-3.5 border-t border-white/5 flex flex-col gap-2.5">
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    setIsAdminOpen(!isAdminOpen);
                  }}
                  className="flex items-center justify-center gap-1.5 rounded-lg border border-brand-yellow bg-brand-yellow/10 py-2.5 text-xs text-brand-yellow font-mono"
                >
                  <Sliders className="h-3.5 w-3.5" />
                  Advisor CRM Board Panel
                </button>
                <div className="text-center text-[10px] text-gray-400 font-mono mt-2">
                  Hotline advisor: +91 9121936522
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Embedded Admin Panel Drawer when toggled active */}
      <AnimatePresence>
        {isAdminOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="mx-auto max-w-7xl px-4 py-8 md:px-8 bg-brand-blue/30"
          >
            <div className="relative">
              <button
                onClick={() => setIsAdminOpen(false)}
                className="absolute top-4 right-4 bg-white/5 text-gray-400 hover:text-white hover:bg-white/10 p-2 rounded-xl transition-colors cursor-pointer"
                title="Hide Board"
              >
                <X className="h-4.5 w-4.5" />
              </button>
              <AdminPanel onClose={() => setIsAdminOpen(false)} onRefreshStats={() => {}} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* HERO SECTION */}
      <section className="relative overflow-hidden py-16 md:py-24 border-b border-white/5">
        
        {/* Abstract design elements background */}
        <div className="absolute top-1/4 right-0 -z-10 h-96 w-96 rounded-full bg-brand-yellow/5 blur-3xl"></div>
        <div className="absolute bottom-1/4 left-0 -z-10 h-[500px] w-[500px] rounded-full bg-blue-500/5 blur-[120px]"></div>

        <div className="mx-auto max-w-7xl px-4 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Hero text items */}
          <div className="lg:col-span-7 space-y-6 md:space-y-8">
            <div className="inline-flex items-center gap-2 rounded-full border border-brand-yellow/20 bg-brand-yellow/5 px-4.5 py-1.5 text-xs font-semibold text-brand-yellow shadow-inner">
              <Sparkles className="h-4.5 w-4.5 stroke-[2.5] animate-spin" style={{ animationDuration: "10s" }} />
              2026-2027 Admissions Stays Are LIVE
            </div>

            <h1 className="font-display text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-6xl leading-[1.05]">
              Premium Student Living <br />
              <span className="text-brand-yellow bg-clip-text">Near Your Campus</span>
            </h1>

            <p className="max-w-xl text-base md:text-lg text-gray-300 font-light leading-relaxed">
              Safe, comfortable & premium student housing fully customized for students of{" "}
              <strong className="text-white font-medium">Amity University Bengaluru</strong> and{" "}
              <strong className="text-white font-medium font-semibold">GITAM University</strong>. Experience high-end amenities starting from just ₹9,000/month.
            </p>

            {/* Badges matrix */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: "200 Mbps Wi-Fi", desc: "Dual fiber lines" },
                { label: "Gourmet Meals", desc: "North-South chef food" },
                { label: "Face Scan Access", desc: "Lady & male wardens" },
                { label: "Complimentary Shuttle", desc: "Every 15 minutes drop" }
              ].map((b, idx) => (
                <div key={idx} className="rounded-xl border border-white/5 bg-white/2 p-3 text-left">
                  <p className="font-display font-bold text-xs text-white">{b.label}</p>
                  <p className="text-[10px] text-gray-400 mt-0.5">{b.desc}</p>
                </div>
              ))}
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4 pt-2">
              <button
                onClick={() => scrollToSection(contactFormRef)}
                className="rounded-xl bg-brand-yellow px-8 py-4.5 text-sm font-bold text-brand-blue hover:bg-brand-yellow-hover focus:outline-none transition-all shadow-xl shadow-brand-yellow/15 cursor-pointer text-center"
              >
                Book Your Stay
              </button>

              <a
                href="https://wa.me/9121936522?text=Hello!%20I%20want%20to%20inquire%20about%20WeStay4U%20student%20accommodations%20near%20Amity%20/%20GITAM"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 px-8 py-4.5 text-sm font-bold text-white hover:bg-white/10 transition-colors"
              >
                <MessageSquare className="h-4.5 w-4.5 text-emerald-400 fill-emerald-400" />
                WhatsApp Advisor
              </a>
            </div>

            {/* Quick trust counts */}
            <div className="flex items-center gap-6 pt-4 border-t border-white/5">
              <div className="flex -space-x-3.5">
                {[
                  "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=80",
                  "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=80",
                  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=80",
                  "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&q=80&w=80"
                ].map((av, avIdx) => (
                  <img
                    key={avIdx}
                    src={av}
                    className="h-9 w-9 rounded-full border-2 border-brand-blue object-cover"
                    alt="Active Resident"
                    referrerPolicy="no-referrer"
                  />
                ))}
              </div>
              <div>
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-brand-yellow text-brand-yellow" />
                  ))}
                  <span className="font-mono text-xs font-bold text-white ml-2">4.9/5 Star Log</span>
                </div>
                <p className="text-xs text-gray-400 font-mono mt-0.5">Approved by 450+ Parents & Students</p>
              </div>
            </div>
          </div>

          {/* Hero visuals container with layered graphics */}
          <div className="lg:col-span-5 relative mt-6 lg:mt-0 flex justify-center">
            <div className="relative w-full max-w-[380px] md:max-w-[420px]">
              
              {/* Main picture card */}
              <div className="overflow-hidden rounded-2xl border border-white/10 shadow-2xl relative group">
                <img
                  src="https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&q=80&w=800"
                  alt="Premium Student Room accommodation setup"
                  className="h-[430px] w-full object-cover grayscale-[10%] group-hover:scale-[1.02] transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                
                {/* Visual shade gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-brand-blue via-transparent to-black/10"></div>
                
                {/* Visual graphic card over visual room */}
                <div className="absolute bottom-5 left-5 right-5 rounded-xl bg-brand-blue/90 border border-white/10 p-4.5 backdrop-blur-md">
                  <span className="text-[9px] font-mono uppercase tracking-widest text-[#FFD700] font-bold block">PRESIDENTIAL WING</span>
                  <h4 className="font-display font-bold text-base text-white mt-1">Single Posture-Pedic Suite</h4>
                  <div className="flex items-center justify-between mt-3 font-mono text-xs">
                    <span className="text-gray-400">Monthly Rates:</span>
                    <span className="text-[#FFD700] font-bold font-semibold text-sm">Starts at ₹18,000</span>
                  </div>
                </div>
              </div>

              {/* Floating physical badge absolute */}
              <div className="absolute -top-4 -right-4 rounded-2xl bg-brand-yellow text-brand-blue p-3.5 shadow-2xl animate-bounce" style={{ animationDuration: "3.5s" }}>
                <Clock className="h-5 w-5 mx-auto" />
                <p className="text-[10px] font-display font-extrabold tracking-tight text-center mt-1 uppercase">
                  3 MIN TRANST TO AMITY
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2: WHY CHOOSE WESTAY4U */}
      <section id="why-choose" className="py-16 md:py-24 bg-brand-blue-light/20">
        <div className="mx-auto max-w-7xl px-4 md:px-8 space-y-12">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="rounded-full bg-brand-yellow/10 border border-brand-yellow/15 px-3.5 py-1 text-xs font-mono font-semibold tracking-wider text-brand-yellow uppercase">
              The Premium Difference
            </span>
            <h2 className="font-display text-3xl font-bold tracking-tight text-white sm:text-4xl">
              Why 450+ Hostellers Pick WeStay4U
            </h2>
            <p className="text-sm md:text-base text-gray-300 font-light">
              We bridge standard hostel affordability with luxury, safety, and physical closeness to the classrooms.
            </p>
          </div>

          {/* Cards Section - Complete Asymmetric Bento Grid Layout */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-4">
            {[
              {
                title: "Premium Furnished Rooms",
                desc: "Equipped with split air conditioning controllers, personal lockboxes, massive reading desks, custom bedside shelves, and orthopaedic bedding mattresses.",
                icon: <Building className="h-6 w-6 text-brand-yellow" />,
                metric: "Luxury finishes",
                span: "lg:col-span-8",
                isWhite: false
              },
              {
                title: "Lag-Free 200 Mbps Fiber Wifi",
                desc: "High velocity dual carriers routers embedded inside corridor channels. Smoothly stream presentations, write intensive code, or coordinate group projects.",
                icon: <Wifi className="h-6 w-6 text-brand-yellow" />,
                metric: "100% stable uptime",
                span: "lg:col-span-4",
                isWhite: false
              },
              {
                title: "Ironclad Security Shield",
                desc: "Biometric face lock logging, CCTV cameras active on stairwells and lobbies, and active dual physical wardens permanently residing on residential floors.",
                icon: <ShieldCheck className="h-6 w-6 text-[#09090b]" />,
                metric: "Parent peace of mind",
                span: "lg:col-span-4",
                isWhite: true // Highlight card
              },
              {
                title: "Daily Professional Hygiene Chef",
                desc: "Four healthy high-dietary meals served daily in neat setups. Features custom pure-vegetarian separately sourced North & South Indian meals.",
                icon: <ChefHat className="h-6 w-6 text-brand-yellow" />,
                metric: "4 meals inclusive",
                span: "lg:col-span-4",
                isWhite: false
              },
              {
                title: "Immediate College Transit Shuttles",
                desc: "Complimentary, regular AC transports operating back and forth from GITAM and Amity campuses doors every fifteen minutes.",
                icon: <Car className="h-6 w-6 text-brand-yellow" />,
                metric: "Zero auto expenses",
                span: "lg:col-span-4",
                isWhite: false
              },
              {
                title: "Empowering Private Cohorts",
                desc: "Hangouts in gaming zones with modern PlayStation 5, foosball and ping pong. Form deep study networks with high academic seniors. Live as an progressive family.",
                icon: <Gamepad2 className="h-6 w-6 text-brand-yellow" />,
                metric: "Active common circles",
                span: "lg:col-span-12",
                isWhite: false
              }
            ].map((card, idx) => (
              <div
                key={idx}
                className={`group relative rounded-2xl border p-6 md:p-8 flex flex-col justify-between transition-all duration-300 ${card.span} ${
                  card.isWhite
                    ? "bg-[#fafafa] text-[#09090b] border-zinc-200 shadow-xl"
                    : "bg-[#111114] text-zinc-300 border-zinc-800/80 hover:border-zinc-700 hover:bg-[#151519]"
                }`}
              >
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <div className={`flex h-11 w-11 items-center justify-center rounded-xl border mb-1 ${
                      card.isWhite 
                        ? "bg-[#09090b] border-[#09090b]/10 text-white" 
                        : "bg-zinc-900 border-zinc-800 text-brand-yellow"
                    }`}>
                      {card.icon}
                    </div>
                    <span className={`text-[9px] font-mono tracking-wider uppercase px-2.5 py-0.5 rounded-full border ${
                      card.isWhite 
                        ? "bg-[#09090b]/5 border-[#09090b]/10 text-[#09090b] font-bold" 
                        : "bg-zinc-800/30 border-zinc-800 text-zinc-500"
                    }`}>
                      {card.metric}
                    </span>
                  </div>

                  <h3 className={`font-display text-xl font-bold tracking-tight mb-2.5 ${
                    card.isWhite ? "text-[#09090b]" : "text-white group-hover:text-brand-yellow transition-colors"
                  }`}>
                    {card.title}
                  </h3>

                  <p className={`text-xs leading-relaxed font-light ${
                    card.isWhite ? "text-zinc-700" : "text-zinc-400"
                  }`}>
                    {card.desc}
                  </p>
                </div>

                <div className={`mt-6 pt-3 border-t border-dashed text-[10px] font-mono tracking-tight flex items-center justify-between ${
                  card.isWhite ? "border-zinc-300 text-zinc-500" : "border-zinc-800/80 text-zinc-600"
                }`}>
                  <span>STUDENT INCLUSIVE PROVISION</span>
                  <span className="font-bold">WS // CODE_SAFE</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 3: NEARBY UNIVERSITIES SECTION */}
      <section id="universities" className="py-16 md:py-24 border-y border-white/5">
        <div className="mx-auto max-w-7xl px-4 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-6 space-y-6 md:space-y-8">
            <span className="text-xs font-mono font-bold tracking-widest text-[#FFD700] uppercase block">LOCATION ADVANTAGE</span>
            <h2 className="font-display text-3xl font-bold tracking-tight text-white sm:text-4xl">
              Stay Close to Your Campus
            </h2>
            <p className="text-sm md:text-base text-gray-300 font-light leading-relaxed">
              Why wake up hours earlier, waste money on autos, and fight traffic? WeStay4U was planned specifically for student proximity, with regular private shuttle sweeps dropping you right off inside gates of local campuses.
            </p>

            <div className="space-y-4">
              {UNIVERSITIES.map((uni, idx) => (
                <div key={idx} className="rounded-2xl border border-white/10 bg-brand-blue-light/40 p-5.5 flex items-start sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="h-11 w-11 rounded-xl bg-brand-yellow/5 border border-brand-yellow/10 flex items-center justify-center font-display font-extrabold text-[#FFD700] text-sm shrink-0">
                      WS
                    </div>
                    <div>
                      <h4 className="font-display font-semibold text-sm text-white">
                        {uni.name}
                      </h4>
                      <p className="text-[11px] text-gray-400 font-mono mt-0.5">
                        Distance from WeStay4U Door: <strong className="text-brand-yellow font-semibold">{uni.distanceKm} km</strong>
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-right font-mono shrink-0">
                    <div className="bg-brand-blue px-2.5 py-1.5 rounded-lg border border-white/5 text-center">
                      <p className="text-[#FFD700] font-bold text-xs">{uni.autoMinutes} mins</p>
                      <p className="text-[9px] text-gray-400 uppercase">Shuttle</p>
                    </div>
                    <div className="bg-brand-blue px-2.5 py-1.5 rounded-lg border border-white/5 text-center">
                      <p className="text-[#FFD700] font-bold text-xs">{uni.walkMinutes} mins</p>
                      <p className="text-[9px] text-gray-400 uppercase">Walkway</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="rounded-xl bg-brand-yellow/5 border border-brand-yellow/15 p-4.5 flex items-center gap-3">
              <Car className="h-5 w-5 text-brand-yellow shrink-0 animate-bounce" />
              <p className="text-xs text-brand-yellow font-medium">
                <strong>Complimentary shuttle access card included:</strong> Free pick-and-drop credentials for all active hostel occupants!
              </p>
            </div>
          </div>

          {/* Map layout or visual vector representation */}
          <div className="lg:col-span-6 rounded-2xl border border-white/10 bg-brand-blue-light p-5 md:p-7 relative select-none">
            <p className="text-xs font-mono uppercase text-[#FFD700] font-semibold mb-4">MAP INTERACTION PLAN</p>
            
            {/* Mock Vector Campus Map */}
            <div className="h-80 w-full rounded-xl border border-white/10 bg-brand-blue relative overflow-hidden flex items-center justify-center p-4">
              {/* grid pattern */}
              <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:20px_20px]"></div>
              
              {/* Route line */}
              <svg className="absolute inset-0 h-full w-full" xmlns="http://www.w3.org/2000/svg">
                <path d="M 120, 160 Q 200, 120 280, 200 T 400, 140" fill="none" stroke="#FFD700" strokeWidth="3" strokeDasharray="6" className="animate-[dash_10s_linear_infinite]" />
              </svg>

              {/* WeStay node */}
              <div className="absolute top-[150px] left-[110px] z-10 rounded-xl bg-brand-yellow text-brand-blue px-3 py-1 font-display font-extrabold text-[10px] tracking-tight text-center shadow-lg">
                WeStay4U
              </div>

              {/* Amity Node */}
              <div className="absolute top-[180px] right-[70px] z-10 rounded-lg border border-white/20 bg-brand-blue-light p-2.5 font-display font-semibold text-[10px] text-white">
                🏫 Amity University
                <p className="text-[8px] font-mono text-gray-400 mt-1 uppercase text-[#FFD700]">1.2 KM / FREE SHUTTLE</p>
              </div>

              {/* GITAM Node */}
              <div className="absolute top-[80px] right-[160px] z-10 rounded-lg border border-white/20 bg-brand-blue-light p-2.5 font-display font-semibold text-[10px] text-white">
                🏫 GITAM Campus
                <p className="text-[8px] font-mono text-gray-400 mt-1 uppercase text-[#FFD700]">1.5 KM / FREE SHUTTLE</p>
              </div>

              {/* Route Indicator Legend inside map */}
              <div className="absolute bottom-3 left-3 bg-brand-blue-light/90 border border-white/10 px-2.5 py-1.5 rounded-lg text-[9px] font-mono text-gray-400">
                <div className="flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-brand-yellow"></span> Shuttle Transit Route
                </div>
              </div>
            </div>

            <div className="mt-4.5 text-center text-xs text-gray-400 font-mono">
              📍 Localities: Chapparkal Road, Avati, Bengaluru Rural (Near National Highway-7)
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 4: PREMIUM PACKAGES SECTION */}
      <section className="py-16 md:py-24 bg-brand-blue-light/10">
        <div className="mx-auto max-w-7xl px-4 md:px-8 space-y-12">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="rounded-full bg-[#FFD700]/10 border border-[#FFD700]/15 px-3.5 py-1 text-xs font-mono font-semibold tracking-wider text-[#FFD700] uppercase">
              Financial Security
            </span>
            <h2 className="font-display text-3xl font-bold tracking-tight text-white sm:text-4xl">
              Flagship Student Housing Pricing Packs
            </h2>
            <p className="text-sm md:text-base text-gray-300 font-light">
              We charge all-inclusive flat rates with standard refundable deposits. Choose how you stay.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            
            {/* Plan 1 */}
            <div className="rounded-2xl border border-white/10 bg-brand-blue p-6 md:p-8 flex flex-col justify-between space-y-8 relative hover:border-white/20 transition-all">
              <div className="space-y-4">
                <p className="text-xs font-semibold uppercase text-gray-400 font-mono">STAND-BY STAY</p>
                <h3 className="font-display text-2xl font-bold text-white">Monthly Standard Pack</h3>
                <p className="text-sm text-gray-300 font-light">
                  A flexible month-on-month program that secures premium rooms, high-speed fiber wi-fi, professional daily deep janitorial housekeeping, and 24-hr wardens without commitment.
                </p>
                
                <div className="border-t border-white/5 pt-4 space-y-2.5">
                  {[
                    "Full utility billing inclusive",
                    "Choose sharing level freely",
                    "Shuttle priority seat cards",
                    "4 core student meals daily"
                  ].map((f, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-gray-300 font-light">
                      <span className="h-1.5 w-1.5 rounded-full bg-[#FFD700]"></span> {f}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-[10px] font-mono uppercase text-gray-500 block">STARTING VALUE PRICE</span>
                <span className="text-3xl font-display font-extrabold text-[#FFD700]">₹9,000</span>
                <span className="text-xs text-gray-400 font-mono"> / Month</span>
                
                <button
                  onClick={() => {
                    setLeadStay("Monthly Standard Plan");
                    scrollToSection(contactFormRef);
                  }}
                  className="w-full rounded-xl border border-white/10 bg-white/5 py-3.5 mt-5 font-display font-semibold text-xs text-white hover:bg-white/10 transition-colors cursor-pointer text-center"
                >
                  Choose Monthly
                </button>
              </div>
            </div>

            {/* Plan 2 */}
            <div className="rounded-2xl border border-brand-yellow bg-brand-blue-light/60 p-6 md:p-8 flex flex-col justify-between space-y-8 relative hover:border-brand-yellow-hover transition-all">
              
              {/* Popular stamp */}
              <div className="absolute -top-3 right-6 rounded-full bg-[#FFD700] text-brand-blue px-3.5 py-1 text-[10px] font-mono font-bold uppercase tracking-wider">
                👑 4 Years. Zero Worries. Plan
              </div>

              <div className="space-y-4">
                <p className="text-xs font-semibold uppercase text-[#FFD700] font-mono">LOCKED-IN DEGREE OPTION</p>
                <h3 className="font-display text-2xl font-bold text-white">4-Year Degree-Stay Plan</h3>
                <p className="text-sm text-gray-300 font-light">
                  Lock your rental price for the entirety of your 4-year undergraduate programs! Stay protected from annual Bengaluru rental spikes, and live absolute worry-free all semesters.
                </p>
                
                <div className="border-t border-white/5 pt-4 space-y-2.5">
                  {[
                    "Inflation Protection: Lock rates instantly",
                    "10% Direct Plan discounts applied",
                    "Complimentary VIP exam laundry sheets",
                    "Priority check-in and pick of suites",
                    "Direct internship references with cohorts"
                  ].map((f, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-gray-300 font-light">
                      <span className="h-1.5 w-1.5 rounded-full bg-[#FFD700]"></span> {f}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-[10px] font-mono uppercase text-gray-400 block pb-1">TAILORED ANNUAL DEALS</span>
                <span className="text-3xl font-display font-extrabold text-[#FFD700]">Lock Rent & Shield Inflation</span>
                
                <button
                  onClick={() => {
                    setLeadStay("Degree-Stay Plan (4 Years locked)");
                    scrollToSection(contactFormRef);
                  }}
                  className="w-full rounded-xl bg-brand-yellow py-3.5 mt-5 font-display font-bold text-xs text-brand-blue hover:bg-brand-yellow-hover transition-all cursor-pointer text-center shadow-md shadow-brand-yellow/15"
                >
                  Reserve Degree Package
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* INTERACTIVE VALUE CALCULATOR HERE */}
      <section className="py-16 md:py-24 mx-auto max-w-7xl px-4 md:px-8" ref={calculatorRef}>
        <InteractiveCalculator onPreSelectConfig={handlePreSelectConfig} />
      </section>

      {/* SECTION 5: ROOM SUITE GRID AND SELECTION OPTIONS */}
      <section id="rooms" ref={roomsRef} className="py-16 md:py-24 border-t border-white/5 bg-brand-blue-light/10">
        <div className="mx-auto max-w-7xl px-4 md:px-8 space-y-12">
          
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-mono font-bold tracking-widest text-[#FFD700] uppercase block">PREMIUM ACCOMMODATIONS</span>
            <h2 className="font-display text-3xl font-bold tracking-tight text-white sm:text-4xl">Our Handcrafted Rooms</h2>
            <p className="text-sm text-gray-300 font-light">
              Choose the exact shared workspace layout that fits your routine. Fully ventilated with natural cross lighting.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {ROOMS.map((room) => (
              <div key={room.id} className="rounded-2xl border border-white/10 bg-brand-blue overflow-hidden hover:border-white/20 hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between">
                
                <div className="relative">
                  <img
                    src={room.image}
                    alt={room.name}
                    className="h-56 w-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-4 left-4 bg-brand-blue/90 border border-white/10 rounded-full px-3 py-1 font-mono text-[10px] uppercase font-bold text-brand-yellow">
                    {room.sharingLevel} Sharing
                  </div>
                </div>

                <div className="p-6 flex-1 flex flex-col justify-between space-y-5">
                  <div className="space-y-2.5">
                    <h3 className="font-display font-bold text-lg text-white">{room.name}</h3>
                    <p className="text-xs text-brand-yellow font-mono italic">{room.tagline}</p>
                    <p className="text-xs text-gray-300 leading-normal font-light">{room.description}</p>
                  </div>

                  <div className="space-y-3 pt-3 border-t border-white/5">
                    <p className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">Included Suite Features</p>
                    <div className="flex flex-wrap gap-1.5">
                      {room.features.map((f, fIdx) => (
                        <span key={fIdx} className="rounded bg-white/5 border border-white/5 px-2 py-0.5 text-[9px] text-gray-300 font-mono">
                          {f}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="p-6 bg-white/1 flex items-center justify-between border-t border-white/5">
                  <div>
                    <span className="text-[9px] font-mono text-gray-400 uppercase block">Flat Price Starts:</span>
                    <span className="text-xl font-display font-extrabold text-[#FFD700]">₹{room.pricePerMonth.toLocaleString()}</span>
                    <span className="text-[10px] text-gray-500 font-mono"> /m</span>
                  </div>

                  <button
                    onClick={() => {
                      setLeadStay(`${room.name} (${room.sharingLevel} sharing)`);
                      scrollToSection(contactFormRef);
                    }}
                    className="rounded-lg bg-brand-yellow px-4 py-2 text-xs font-bold text-brand-blue hover:bg-brand-yellow-hover transition-colors cursor-pointer"
                  >
                    Select Room
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 6: AMENITIES GRID */}
      <section id="amenities" className="py-16 md:py-24 border-y border-white/5">
        <div className="mx-auto max-w-7xl px-4 md:px-8 space-y-12">
          
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-mono font-bold tracking-widest text-brand-yellow uppercase block">INTEGRATED SERVICES</span>
            <h2 className="font-display text-3xl font-bold tracking-tight text-white sm:text-4xl">
              All-Inclusive College Living
            </h2>
            <p className="text-sm text-gray-300 font-light">
              Unlike ordinary PGs with hidden metrics, WeStay4U coordinates everything in your standard flat-rate. Zero worries.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {AMENITIES.map((amenity) => (
              <div key={amenity.id} className="rounded-xl border border-white/5 bg-brand-blue-light/50 p-5 space-y-3.5">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-blue border border-white/5 shadow-sm">
                  {getAmenityIcon(amenity.iconName)}
                </div>
                <div>
                  <h4 className="font-display font-bold text-sm text-white">{amenity.name}</h4>
                  <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block mt-0.5">
                    {amenity.category} Catalog
                  </span>
                  <p className="text-xs text-gray-300 leading-normal font-light mt-2">
                    {amenity.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 7: RESIDENT & PARENTS TESTIMONIAL CARDS */}
      <section className="py-16 md:py-24 bg-brand-blue-light/20">
        <div className="mx-auto max-w-7xl px-4 md:px-8 space-y-12">
          
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="rounded-full bg-brand-yellow/10 border border-brand-yellow/15 px-3 py-1 text-xs font-mono font-bold tracking-wider text-brand-yellow uppercase">
              Parent & Student Reviews
            </span>
            <h2 className="font-display text-3xl font-bold tracking-tight text-white sm:text-4xl">
              Verified Student Narratives
            </h2>
            <p className="text-sm text-gray-300 font-light">
              Real social proofs from parents and undergraduate students who transformed their University experiences.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-7">
            {TESTIMONIALS.map((test) => (
              <div key={test.id} className="rounded-2xl border border-white/5 bg-brand-blue-light p-6 md:p-8 space-y-6 flex flex-col justify-between hover:border-brand-yellow/10 transition-colors">
                
                <div className="space-y-4">
                  {/* Rating Stars */}
                  <div className="flex items-center gap-1">
                    {[...Array(test.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-brand-yellow text-brand-yellow" style={{ filter: "drop-shadow(0 0 4px rgba(255,215,0,0.2))" }} />
                    ))}
                  </div>

                  <p className="text-xs md:text-sm text-gray-200 font-light leading-relaxed italic">
                    "{test.quote}"
                  </p>
                </div>

                <div className="flex items-center gap-3.5 pt-5 border-t border-white/5">
                  <img
                    src={test.avatar}
                    alt={test.author}
                    className="h-10 w-10 rounded-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h5 className="font-display font-semibold text-xs text-white">{test.author}</h5>
                    <span className="rounded bg-brand-yellow/10 text-brand-yellow font-mono text-[9px] px-1.5 py-0.2 uppercase mt-0.5 inline-block">
                      {test.role}
                    </span>
                    <p className="text-[10px] text-gray-400 font-mono mt-0.5">{test.relationDetails}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 8: LIFESTYLE GALLERY WITH LIVE TABS */}
      <section id="gallery" className="py-16 md:py-24 border-t border-white/5">
        <div className="mx-auto max-w-7xl px-4 md:px-8 space-y-10">
          
          <div className="flex flex-col md:flex-row items-baseline justify-between gap-4">
            <div>
              <span className="text-xs font-mono font-bold tracking-widest text-[#FFD700] uppercase block">PREMIUM GALLERY</span>
              <h2 className="font-display text-3xl font-bold tracking-tight text-white mt-1">WeStay4U Resident Gallery</h2>
            </div>

            {/* Live Filter Tab List */}
            <div className="flex flex-wrap gap-1.5 max-w-full overflow-x-auto pb-1">
              {galleryTabs.map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveGalleryTab(tab)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                    activeGalleryTab === tab
                      ? "bg-brand-yellow text-brand-blue"
                      : "border border-white/10 bg-white/5 text-gray-400 hover:text-white hover:bg-white/10"
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {/* Interactive filter gallery grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence mode="popLayout">
              {filteredGallery.map((item, index) => (
                <motion.div
                  key={item.url + index}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.25 }}
                  className="rounded-xl border border-white/5 bg-brand-blue overflow-hidden select-none group relative"
                >
                  <div className="h-56 overflow-hidden relative">
                    <img
                      src={item.url}
                      alt={item.description}
                      className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent"></div>
                  </div>
                  <div className="p-4 absolute bottom-0 left-0 right-0">
                    <span className="rounded bg-brand-yellow/10 border border-brand-yellow/20 px-2 py-0.5 text-[8px] font-mono text-[#FFD700] uppercase font-bold tracking-wider">
                      {item.category}
                    </span>
                    <p className="text-xs text-white font-medium mt-1.5">{item.description}</p>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* SECTION 9: EXPANDABLEFAQ ACCORDION */}
      <section id="faqs" className="py-16 md:py-24 border-y border-white/5 bg-brand-blue-light/10">
        <div className="mx-auto max-w-4xl px-4 md:px-8 space-y-12 animate-fade-in">
          
          <div className="text-center space-y-3">
            <span className="text-xs font-mono font-bold tracking-widest text-[#FFD700] uppercase block">WE CARE FOR STUDENTS</span>
            <h2 className="font-display text-3xl font-bold tracking-tight text-white sm:text-4xl">Frequently Answered Queries</h2>
            <p className="text-sm text-gray-300 font-light">
              Clear parent-assuring insights on stay bookings, safety policies, and amenities.
            </p>
          </div>

          {/* Accordion List */}
          <div className="space-y-3">
            {FAQS.map((faq) => {
              const isOpen = activeFaqId === faq.id;
              return (
                <div
                  key={faq.id}
                  className="rounded-xl border border-white/5 bg-brand-blue overflow-hidden transition-colors duration-200"
                >
                  <button
                    onClick={() => setActiveFaqId(isOpen ? null : faq.id)}
                    className="w-full px-5 py-4 text-left flex items-center justify-between gap-3 focus:outline-none focus:ring-0 cursor-pointer"
                  >
                    <span className="font-display font-bold text-xs sm:text-sm text-white hover:text-brand-yellow transition-colors">
                      {faq.question}
                    </span>
                    <ChevronDown
                      className={`h-4.5 w-4.5 text-gray-400 font-bold shrink-0 transition-transform ${
                        isOpen ? "rotate-180 text-brand-yellow" : ""
                      }`}
                    />
                  </button>

                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                      >
                        <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-gray-300 leading-relaxed font-light border-t border-white/5">
                          {faq.answer}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* SECTION 10: LEAD CAPTURE SECURE FORM SECTION */}
      <section id="contact-form" ref={contactFormRef} className="py-16 md:py-24 max-w-xl mx-auto px-4 md:px-6">
        <div className="rounded-2xl border border-white/10 bg-brand-blue-light p-6 md:p-8 space-y-6 relative">
          
          {/* subtle gold rim */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-brand-yellow rounded-t-2xl"></div>

          <div className="text-center space-y-1.5">
            <h3 className="font-display text-2xl font-extrabold tracking-tight text-white">Book Your Premium Room</h3>
            <p className="text-xs text-gray-400">
              Submit your details to secure locked pricing and regular shuttle passes!
            </p>
          </div>

          {selectedConfigLabel && (
            <div className="rounded-lg bg-[#FFD700]/10 border border-brand-yellow/20 p-2.5 text-xs text-brand-yellow font-mono text-center flex items-center justify-center gap-1.5 animate-pulse">
              <CheckCircle className="h-4 w-4 shrink-0" />
              {selectedConfigLabel}
            </div>
          )}

          {formSuccess ? (
            <div className="py-12 text-center space-y-5">
              <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-400">
                <CheckCircle className="h-9 w-9" />
              </div>
              <h4 className="font-display text-2xl font-bold text-white leading-normal">Inquiry Received Successfully!</h4>
              <p className="text-xs text-gray-300 max-w-md mx-auto">
                Thank you booking with us! Our personal student accommodation advisor is reviewing your request and will reach out to you on your phone within 15 minutes to coordinate on boarding.
              </p>
              
              <div className="pt-4 flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => setFormSuccess(false)}
                  className="flex-1 rounded-xl bg-white/5 border border-white/10 py-3 text-xs text-gray-300 hover:text-white"
                >
                  Submit Another Lead
                </button>
                <a
                  href="https://wa.me/9121936522?text=Hi%20WeStay4U!%20I%20just%20submitted%20my%20lead%20booking%20and%20want%20to%20speed%20up%20reception!"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-1.5 rounded-xl bg-emerald-500 py-3 text-xs font-bold text-white hover:bg-emerald-600 transition-colors"
                >
                  Verify via WhatsApp
                </a>
              </div>
            </div>
          ) : (
            <form onSubmit={handleFormSubmit} className="space-y-4">
              {formError && (
                <div className="rounded-lg bg-red-400/10 border border-red-500/10 p-2 text-center text-xs text-red-400 font-mono">
                  {formError}
                </div>
              )}

              <div className="space-y-4">
                {/* Name */}
                <div>
                  <label htmlFor="lead-form-name" className="block text-[11px] font-mono uppercase tracking-wider text-gray-400 mb-1">
                    Student Full Name
                  </label>
                  <input
                    id="lead-form-name"
                    type="text"
                    required
                    value={leadName}
                    onChange={(e) => setLeadName(e.target.value)}
                    placeholder="e.g. Ayush Sharma"
                    className="w-full rounded-xl bg-white/5 border border-white/10 py-3 px-4 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-brand-yellow text-sm"
                  />
                </div>

                {/* Phone */}
                <div>
                  <label htmlFor="lead-form-phone" className="block text-[11px] font-mono uppercase tracking-wider text-gray-400 mb-1">
                    Phone Number (WhatsApp preferred)
                  </label>
                  <input
                    id="lead-form-phone"
                    type="tel"
                    required
                    value={leadPhone}
                    onChange={(e) => setLeadPhone(e.target.value)}
                    placeholder="e.g. +91 91219 36522"
                    className="w-full rounded-xl bg-white/5 border border-white/10 py-3 px-4 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-brand-yellow text-sm"
                  />
                </div>

                {/* University Selector */}
                <div>
                  <label className="block text-[11px] font-mono uppercase tracking-wider text-gray-400 mb-1">
                    Target University Campus
                  </label>
                  <select
                    value={leadUni}
                    onChange={(e) => setLeadUni(e.target.value)}
                    className="w-full rounded-xl bg-white/5 border border-white/10 py-3 px-4 text-xs text-gray-200 focus:outline-none focus:border-brand-yellow text-sm appearance-none cursor-pointer"
                  >
                    <option value="Amity University Bengaluru" className="bg-brand-blue-light text-white">Amity University Bengaluru (~1.2km away)</option>
                    <option value="GITAM University" className="bg-brand-blue-light text-white">GITAM University (~1.5km away)</option>
                    <option value="Other Bengaluru University" className="bg-brand-blue-light text-white">Other Institute in Bengaluru Area</option>
                  </select>
                </div>

                {/* Preferred Stay Duration Option */}
                <div>
                  <label className="block text-[11px] font-mono uppercase tracking-wider text-gray-400 mb-1">
                    Preferred Stay Package Duration
                  </label>
                  <select
                    value={leadStay}
                    onChange={(e) => setLeadStay(e.target.value)}
                    className="w-full rounded-xl bg-white/5 border border-white/10 py-3 px-4 text-xs text-gray-200 focus:outline-none focus:border-brand-yellow text-sm appearance-none cursor-pointer"
                  >
                    <option value="Degree-Stay Plan (4 Years locked)" className="bg-brand-blue-light text-white">Degree-Stay Plan (4 Years locked: 10% Off)</option>
                    <option value="Annual Year Pack (10 Months)" className="bg-brand-blue-light text-white">Annual Academic Year Package (10 Months: 5% Off)</option>
                    <option value="Monthly Stay Pack" className="bg-brand-blue-light text-white">Monthly Flex Standard (Commitment-Free)</option>
                  </select>
                </div>
              </div>

              <div className="pt-4">
                <button
                  type="submit"
                  disabled={formSubmitting}
                  className="w-full rounded-xl bg-brand-yellow py-3.5 text-center font-display font-extrabold text-xs uppercase tracking-wider text-brand-blue hover:bg-brand-yellow-hover focus:outline-none transition-all cursor-pointer shadow-lg shadow-brand-yellow/10"
                >
                  {formSubmitting ? "Locking Your Offer..." : "Submit Stay Inquiry"}
                </button>
              </div>

              {/* Secure statement */}
              <p className="text-[10px] text-gray-500 font-mono text-center mt-2 flex items-center justify-center gap-1.5">
                <Lock className="h-3 w-3" /> GDPR & safety compliant. No spam updates.
              </p>
            </form>
          )}
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-white/5 bg-brand-blue-light/40 py-12 text-gray-400">
        <div className="mx-auto max-w-7xl px-4 md:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
          
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-yellow text-brand-blue font-extrabold text-sm font-display tracking-tight">
                W
              </div>
              <span className="font-display text-base font-bold text-white tracking-tight">
                WeStay<span className="text-brand-yellow">4U</span>
              </span>
            </div>
            
            <p className="text-xs text-gray-300 font-light leading-relaxed">
              Premium modern student living near Amity University Bengaluru and GITAM University. Run by student accommodation gurus since 2019.
            </p>
          </div>

          <div>
            <h5 className="font-display font-semibold text-xs tracking-wider uppercase text-white mb-4">Contact Info</h5>
            <div className="space-y-2.5 text-xs font-mono">
              <p className="text-gray-300">📞 Call: +91 9121936522</p>
              <p className="text-gray-300">💬 WA: +91 9121936522</p>
              <p className="text-gray-300">✉️ advisor@westay4u.com</p>
            </div>
          </div>

          <div>
            <h5 className="font-display font-semibold text-xs tracking-wider uppercase text-white mb-4">Quick Links</h5>
            <div className="space-y-2 text-xs">
              <button onClick={() => scrollToSection(roomsRef)} className="block hover:text-brand-yellow transition-colors text-left cursor-pointer">Stay Catalog</button>
              <button onClick={() => scrollToSection(calculatorRef)} className="block hover:text-brand-yellow transition-colors text-left cursor-pointer">Live Cost Estimator</button>
              <a href="#amenities" className="block hover:text-brand-yellow transition-colors">Amenities Check</a>
              <a href="#faqs" className="block hover:text-brand-yellow transition-colors">Safety Accordions</a>
            </div>
          </div>

          <div>
            <h5 className="font-display font-semibold text-xs tracking-wider uppercase text-white mb-4">Accommodation Headquarters</h5>
            <p className="text-xs text-gray-300 font-light leading-relaxed">
              WeStay4U Towers, Chapparkal Road, Near GITAM University back-gate entrance, Doddaballapura Taluk, Bengaluru Rural, Karnataka, India - 561203.
            </p>
          </div>
        </div>

        <div className="mx-auto max-w-7xl px-4 md:px-8 pt-8 mt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono">
          <p>© 2026 WeStay4U Student Living Pvt Ltd. All rights reserved.</p>
          <div className="flex gap-4">
            <span className="text-gray-500 hover:text-white cursor-pointer select-none" onClick={() => setIsAdminOpen(true)}>Advisor Login</span>
            <span className="text-gray-500">Privacy Policy</span>
            <span className="text-gray-500 font-semibold">Bengaluru, KA, India</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
