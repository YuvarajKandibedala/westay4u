import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Sparkles, Send, GraduationCap, Phone, User, CheckCircle2 } from "lucide-react";

export default function LeadPopup() {
  const [isVisible, setIsVisible] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [university, setUniversity] = useState("Amity University Bengaluru");
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    // Check if user has already dismissed or filled the popup during this session
    const status = sessionStorage.getItem("westay-popup-dismissed");
    if (status === "true") return;

    // Launch exactly after 20 seconds
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 20000);

    return () => clearTimeout(timer);
  }, []);

  const handleDismiss = () => {
    setIsVisible(false);
    sessionStorage.setItem("westay-popup-dismissed", "true");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      setError("Please fill in both Name and Phone.");
      return;
    }

    setSubmitting(true);
    setError("");

    try {
      const response = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          phone,
          university,
          preferredStay: "Lead Popup Offer Match"
        })
      });

      if (response.ok) {
        setSubmitted(true);
        sessionStorage.setItem("westay-popup-dismissed", "true");
        // Hide after 3 seconds automatic
        setTimeout(() => {
          setIsVisible(false);
        }, 3000);
      } else {
        setError("Something went wrong. Please try again or WhatsApp us directly!");
      }
    } catch (err) {
      setError("Unable to submit. Please check your data or internet connection.");
    } finally {
      setSubmitting(false);
    }
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-md overflow-hidden rounded-2xl border border-white/10 bg-brand-blue-light text-white shadow-2xl"
        >
          {/* Top visual graphic accent */}
          <div className="h-1.5 w-full bg-brand-yellow"></div>

          {/* Dismiss button */}
          <button
            onClick={handleDismiss}
            className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>

          <div className="p-6 md:p-8">
            {!submitted ? (
              <form onSubmit={handleSubmit} className="space-y-4 font-sans">
                <div className="text-center">
                  <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-brand-yellow/10 text-brand-yellow mb-3">
                    <Sparkles className="h-6 w-6 animate-pulse" />
                  </div>
                  <h3 className="font-display text-xl font-bold tracking-tight text-white">
                    Looking for premium student accommodation?
                  </h3>
                  <p className="text-xs text-gray-400 mt-1.5 max-w-sm mx-auto">
                    Secure an exclusive **₹2,000 Early Bird Booking Discount** and priority shuttle selection now!
                  </p>
                </div>

                {error && (
                  <div className="rounded-lg bg-red-500/10 p-2.5 text-center text-xs text-red-400 font-mono">
                    {error}
                  </div>
                )}

                <div className="space-y-3.5 mt-5">
                  {/* Name field */}
                  <div>
                    <label className="block text-[11px] font-mono uppercase tracking-wider text-gray-400 mb-1">
                      Full Name
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Rahul Verma"
                        className="w-full rounded-xl bg-white/5 border border-white/10 py-2.5 pl-10 pr-4 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-brand-yellow text-sm"
                      />
                    </div>
                  </div>

                  {/* Phone field */}
                  <div>
                    <label className="block text-[11px] font-mono uppercase tracking-wider text-gray-400 mb-1">
                      Phone Number
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="e.g. +91 98765 43210"
                        className="w-full rounded-xl bg-white/5 border border-white/10 py-2.5 pl-10 pr-4 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-brand-yellow text-sm"
                      />
                    </div>
                  </div>

                  {/* University field */}
                  <div>
                    <label className="block text-[11px] font-mono uppercase tracking-wider text-gray-400 mb-1">
                      Your University
                    </label>
                    <div className="relative">
                      <GraduationCap className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                      <select
                        value={university}
                        onChange={(e) => setUniversity(e.target.value)}
                        className="w-full rounded-xl bg-white/5 border border-white/10 py-2.5 pl-10 pr-4 text-xs text-gray-200 focus:outline-none focus:border-brand-yellow text-sm appearance-none cursor-pointer"
                      >
                        <option value="Amity University Bengaluru" className="bg-brand-blue-light text-white">
                          Amity University Bengaluru
                        </option>
                        <option value="GITAM University" className="bg-brand-blue-light text-white">
                          GITAM University
                        </option>
                        <option value="Other Bengaluru University" className="bg-brand-blue-light text-white">
                          Other / Moving to Bengaluru
                        </option>
                      </select>
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full rounded-xl bg-brand-yellow py-3 text-center font-display font-bold text-xs text-brand-blue hover:bg-brand-yellow-hover transition-all mt-6 cursor-pointer"
                >
                  {submitting ? "Securing Your Discount..." : "Lock Offer & Request Call"}
                </button>
              </form>
            ) : (
              <div className="py-8 text-center space-y-4 font-sans">
                <div className="inline-flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-400">
                  <CheckCircle2 className="h-8 w-8" />
                </div>
                <h3 className="font-display text-2xl font-bold text-white leading-normal">
                  Inquiry Locked-In!
                </h3>
                <p className="text-xs text-gray-300 max-w-sm mx-auto">
                  Thank you! We've registered your early bird coupon. Our advisor will reach out shortly on **{phone}** with tailored stays.
                </p>
              </div>
            )}
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
