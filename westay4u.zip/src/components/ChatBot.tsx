import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MessageSquare, X, Send, User, Sparkles, AlertCircle, ArrowRight } from "lucide-react";
import { ChatMessage } from "../types";

const SUGGESTIONS = [
  "How far is Amity University?",
  "What is the price of Double Sharing?",
  "Is the food North Indian or South Indian?",
  "Tell me about parent safety features."
];

export default function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [hasNewMessage, setHasNewMessage] = useState(true); // Alert dot on launcher
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      role: "model",
      text: "👋 **Hello student or parent!** I am the **WeStay AI Guru**.\n\nAsk me anything about our premium stays near **Amity University** and **GITAM University Bengaluru**! I can answer questions about shuttle timings, food hygiene, room spacing, and pricing.",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, loading]);

  const handleOpen = () => {
    setIsOpen(true);
    setHasNewMessage(false);
  };

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMessage: ChatMessage = {
      id: `m-${Date.now()}`,
      role: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      const chatHistory = messages
        .filter((m) => m.id !== "welcome")
        .slice(-6) // Send last 6 messages for context
        .map((m) => ({
          role: m.role,
          text: m.text
        }));

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: textToSend,
          chatHistory
        })
      });

      const data = await response.json();

      if (response.ok && data.reply) {
        setMessages((prev) => [
          ...prev,
          {
            id: `reply-${Date.now()}`,
            role: "model",
            text: data.reply,
            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
          }
        ]);
      } else {
        // Fallback responses in case the backend or Gemini key is unconfigured, ensuring flawless UX
        let fallbackAnswer = "Our AI is currently offline, but here is a direct answer: We are located adjacent to both campuses! WeStay4U offers a **complimentary daily pick-and-drop shuttle service** straight to the gates of Amity University Bengaluru (1.2 km away) and GITAM University (1.5 km away) every 15 minutes.";
        
        const q = textToSend.toLowerCase();
        if (q.includes("price") || q.includes("cost") || q.includes("monthly") || q.includes("rent")) {
          fallbackAnswer = "💵 **WeStay4U Transparent Monthly Pricing:**\n\n- **Presidential Single Suite**: Starts at **₹18,000/month** (private workspace, luxury bath).\n- **Classic Co-Living Double**: Starts at **₹12,000/month** (shared with 1 partner).\n- **Buddy Triple Sharing**: Starts at **₹9,000/month** (maximum budget value).\n\n*All plans are all-inclusive of 4 gourmet chef meals, low-latency Wi-Fi, heavy laundry, and utility backups.*";
        } else if (q.includes("food") || q.includes("meal") || q.includes("eat") || q.includes("vegetarian")) {
          fallbackAnswer = "🍳 **Hygienic 4-Meals Policy:**\n\nWe provide Breakfast, Lunch, High-Tea with hot snacks, and Dinner. Our professional chefs specialize in clean, nutritious **North Indian** and **South Indian** varieties. We use physically separate vegetarian cooking counters and source raw organic ingredients fresh daily.";
        } else if (q.includes("safety") || q.includes("safe") || q.includes("girls") || q.includes("security") || q.includes("parent")) {
          fallbackAnswer = "🛡️ **Ironclad Safety for Students:**\n\n- Secure biometric facial-scans at the main door.\n- Continuous 24/7 CCTV surveillance in common lounges, lobbies, and corridors.\n- Live-in female wardens for the girls' wings and male wardens for boys' wings.\n- Direct medical tie-up with surrounding multispecialty hospitals for any midnight emergency.";
        } else if (q.includes("amity")) {
          fallbackAnswer = "🏫 **Amity University Bengaluru Proximity:**\nWe are situated exactly **1.2 km away** from the Amity campus. Taking our free WeStay shuttle takes exactly **3 minutes**. If you wish to walk, there is a beautifully paved sidewalk taking about 8-10 minutes.";
        } else if (q.includes("gitam")) {
          fallbackAnswer = "🏫 **GITAM University Proximity:**\nWe are only **1.5 km away** from global GITAM campus gates. Our regular non-stop shuttle drop takes exactly **4 minutes** to transport students straight to classrooms.";
        }

        setMessages((prev) => [
          ...prev,
          {
            id: `reply-${Date.now()}`,
            role: "model",
            text: fallbackAnswer,
            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
          }
        ]);
      }
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          id: `reply-${Date.now()}`,
          role: "model",
          text: "I had a tiny connection hiccup, but don't worry! You can call our lead desk directly at **+91 9121936522** or use our Book Form on the page to lock in your special offer immediately.",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  // Helper to format simple markdown/bold text in messages
  const formatText = (text: string) => {
    return text.split("\n").map((paragraph, pIdx) => {
      // Simple regex replacement for bold **text**
      const parts = paragraph.split(/(\*\*[^*]+\*\*)/g);
      return (
        <p key={pIdx} className="mb-2 leading-relaxed">
          {parts.map((part, partIdx) => {
            if (part.startsWith("**") && part.endsWith("**")) {
              return (
                <strong key={partIdx} className="font-semibold text-brand-yellow">
                  {part.slice(2, -2)}
                </strong>
              );
            }
            return part;
          })}
        </p>
      );
    });
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {/* Interactive Popup Launcher Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            id="chat-bot-launcher"
            onClick={handleOpen}
            initial={{ scale: 0, y: 50 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0, y: 20 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex h-14 w-14 items-center justify-center rounded-full bg-brand-yellow text-brand-blue shadow-2xl transition-colors hover:bg-brand-yellow-hover focus:outline-none"
          >
            <MessageSquare className="h-6 w-6 stroke-[2.5]" />
            {hasNewMessage && (
              <span className="absolute top-1 right-1 flex h-3.5 w-3.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex h-3.5 w-3.5 rounded-full bg-red-500"></span>
              </span>
            )}
          </motion.button>
        )}
      </AnimatePresence>

      {/* Main Chat Interface Widget */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="chat-bot-window"
            initial={{ opacity: 0, y: 40, scale: 0.92 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 40, scale: 0.92 }}
            transition={{ type: "spring", damping: 25, stiffness: 220 }}
            className="flex h-[520px] w-[360px] flex-col rounded-2xl border border-white/10 bg-brand-blue-light text-white shadow-2xl md:w-[390px]"
          >
            {/* Window Header */}
            <div className="flex items-center justify-between rounded-t-2xl bg-brand-blue px-4 py-3.5 border-b border-white/5">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-yellow/10">
                  <Sparkles className="h-5 w-5 text-brand-yellow animate-pulse" />
                </div>
                <div>
                  <h4 className="font-display font-semibold text-sm tracking-tight flex items-center gap-1.5">
                    WeStay AI Guru
                    <span className="inline-block h-2 w-2 rounded-full bg-emerald-500"></span>
                  </h4>
                  <p className="text-[11px] font-mono text-gray-400">Response time: ~2 seconds</p>
                </div>
              </div>
              <button
                id="close-chat"
                onClick={() => setIsOpen(false)}
                className="rounded-lg p-1.5 text-gray-400 hover:bg-white/5 hover:text-white transition-colors"
              >
                <X className="h-4.5 w-4.5" />
              </button>
            </div>

            {/* Chat History Flow */}
            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 text-xs font-sans">
              {messages.map((m) => (
                <div key={m.id} className={`flex gap-2 ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                  {m.role !== "user" && (
                    <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-brand-yellow text-brand-blue font-bold text-[10px] font-display">
                      WS
                    </div>
                  )}
                  <div className="max-w-[78%]">
                    <div
                      className={`rounded-2xl px-3.5 py-3 ${
                        m.role === "user"
                          ? "bg-brand-yellow text-brand-blue rounded-tr-sm font-medium"
                          : "bg-brand-blue text-gray-100 border border-white/5 rounded-tl-sm"
                      }`}
                    >
                      {formatText(m.text)}
                    </div>
                    <span className="mt-1 block px-1 text-[9px] text-gray-400 font-mono text-right">
                      {m.timestamp}
                    </span>
                  </div>
                  {m.role === "user" && (
                    <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-brand-yellow/10 text-brand-yellow">
                      <User className="h-3.5 w-3.5" />
                    </div>
                  )}
                </div>
              ))}

              {/* Bot Loading/Thinking state */}
              {loading && (
                <div className="flex gap-2 justify-start">
                  <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-brand-yellow text-brand-blue font-bold text-[10px]">
                    WS
                  </div>
                  <div className="rounded-2xl px-3.5 py-3.5 bg-brand-blue border border-white/5 rounded-tl-sm text-gray-400 flex items-center gap-1.5">
                    <span className="h-1 w-1 rounded-full bg-white animate-bounce" style={{ animationDelay: "0ms" }}></span>
                    <span className="h-1 w-1 rounded-full bg-white animate-bounce" style={{ animationDelay: "150ms" }}></span>
                    <span className="h-1 w-1 rounded-full bg-white animate-bounce" style={{ animationDelay: "300ms" }}></span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* suggestion quick chips */}
            {messages.length < 5 && (
              <div className="px-4 py-2 border-t border-white/5 text-[10px] flex flex-wrap gap-1.5 bg-black/10">
                {SUGGESTIONS.map((s, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(s)}
                    className="rounded-full border border-white/10 px-2.5 py-1 text-gray-300 hover:bg-brand-yellow hover:text-brand-blue hover:border-brand-yellow transition-all text-left truncate max-w-full cursor-pointer font-medium"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}

            {/* Input Footer Panel */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage(input);
              }}
              className="p-3 border-t border-white/5 bg-brand-blue flex items-center gap-2 rounded-b-2xl"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about meals, rooms, shuttle..."
                className="flex-1 bg-white/5 rounded-xl px-3 py-2 text-xs border border-white/10 text-white placeholder-gray-400 focus:outline-none focus:border-brand-yellow text-sm font-sans"
              />
              <button
                type="submit"
                disabled={!input.trim() || loading}
                className="flex h-8 w-8 items-center justify-center rounded-xl bg-brand-yellow text-brand-blue hover:bg-brand-yellow-hover disabled:bg-white/5 disabled:text-gray-500 transition-colors cursor-pointer"
              >
                <Send className="h-3.5 w-3.5 stroke-[2.5]" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
