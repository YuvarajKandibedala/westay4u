import React, { useState, useEffect } from "react";
import { Lead } from "../types";
import { Download, RefreshCw, Trash2, Check, HelpCircle, Save, CheckCircle2 } from "lucide-react";

interface AdminPanelProps {
  onClose: () => void;
  onRefreshStats?: () => void;
}

export default function AdminPanel({ onClose, onRefreshStats }: AdminPanelProps) {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [editingNotesId, setEditingNotesId] = useState<string | null>(null);
  const [editingNotesText, setEditingNotesText] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  const fetchLeads = async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/leads");
      if (response.ok) {
        const data = await response.json();
        setLeads(data);
        if (onRefreshStats) onRefreshStats();
      } else {
        setError("Unable to sync booking database from server.");
      }
    } catch (err) {
      setError("Network offline. Ensure server is running correctly.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLeads();
  }, []);

  const handleUpdateStatus = async (id: string, newStatus: string) => {
    try {
      const response = await fetch(`/api/leads/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus })
      });
      if (response.ok) {
        setLeads((prev) =>
          prev.map((l) => (l.id === id ? { ...l, status: newStatus as any } : l))
        );
        showSuccess("Lead status updated.");
      }
    } catch (err) {
      setError("Failed to update status.");
    }
  };

  const handleStartEditingNotes = (lead: Lead) => {
    setEditingNotesId(lead.id);
    setEditingNotesText(lead.notes || "");
  };

  const handleSaveNotes = async (id: string) => {
    try {
      const response = await fetch(`/api/leads/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ notes: editingNotesText })
      });
      if (response.ok) {
        setLeads((prev) =>
          prev.map((l) => (l.id === id ? { ...l, notes: editingNotesText } : l))
        );
        setEditingNotesId(null);
        showSuccess("Follow-up notes saved.");
      }
    } catch (err) {
      setError("Failed to save follow-up notes.");
    }
  };

  const handleDeleteLead = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this lead?")) return;
    try {
      const response = await fetch(`/api/leads/${id}`, { method: "DELETE" });
      if (response.ok) {
        setLeads((prev) => prev.filter((l) => l.id !== id));
        showSuccess("Lead deleted successfully.");
      }
    } catch (err) {
      setError("Failed to delete lead from server.");
    }
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => {
      setSuccessMsg("");
    }, 2500);
  };

  const handleExportCSV = () => {
    if (leads.length === 0) return;
    
    const headers = "ID,Name,Phone,University,Preferred Stay,Status,Follow-up Notes,Date Submitted\r\n";
    const rows = leads.map((l) => {
      return `"${l.id}","${l.name}","${l.phone}","${l.university}","${l.preferredStay}","${l.status}","${(l.notes || "").replace(/"/g, '""')}","${l.createdAt}"`;
    }).join("\r\n");

    const blob = new Blob([headers + rows], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `WeStay4U_Leads_Report_${new Date().toISOString().slice(0, 10)}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Metrics
  const totalLeads = leads.length;
  const newLeads = leads.filter((l) => l.status === "New").length;
  const contactedLeads = leads.filter((l) => l.status === "Contacted").length;
  const bookedLeads = leads.filter((l) => l.status === "Booked").length;

  return (
    <div className="rounded-2xl border border-white/10 bg-brand-blue-light p-6 text-white shadow-2xl space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-yellow-400 animate-pulse"></span>
            <span className="font-mono text-xs text-yellow-400 tracking-wider">SECURE ADVISOR PORTAL</span>
          </div>
          <h2 className="font-display text-2xl font-bold tracking-tight text-white mt-1">Lead Management Dashboard</h2>
        </div>
        
        <div className="flex items-center gap-2.5">
          <button
            onClick={fetchLeads}
            disabled={loading}
            className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-gray-300 hover:text-white hover:bg-white/10 transition-colors disabled:opacity-55 cursor-pointer"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
            Sync
          </button>
          
          <button
            onClick={handleExportCSV}
            disabled={leads.length === 0}
            className="flex items-center gap-1.5 rounded-lg bg-brand-yellow px-3.5 py-1.5 text-xs font-semibold text-brand-blue hover:bg-brand-yellow-hover transition-colors disabled:opacity-40 cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" />
            Download CSV
          </button>
        </div>
      </div>

      {/* Metrics Cards row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="rounded-xl bg-brand-blue border border-white/5 p-4">
          <p className="text-[10px] font-mono text-gray-400 uppercase tracking-wider">Total Leads</p>
          <p className="text-2xl font-display font-bold text-white mt-1">{totalLeads}</p>
        </div>
        <div className="rounded-xl bg-brand-blue border border-white/5 p-4">
          <p className="text-[10px] font-mono text-emerald-400 uppercase tracking-wider">Booked Wins</p>
          <p className="text-2xl font-display font-bold text-emerald-400 mt-1">{bookedLeads}</p>
        </div>
        <div className="rounded-xl bg-brand-blue border border-white/5 p-4">
          <p className="text-[10px] font-mono text-blue-400 uppercase tracking-wider">In Progress</p>
          <p className="text-2xl font-display font-bold text-blue-400 mt-1">{contactedLeads}</p>
        </div>
        <div className="rounded-xl bg-brand-blue border border-white/5 p-4">
          <p className="text-[10px] font-mono text-brand-yellow uppercase tracking-wider">Unaddressed</p>
          <p className="text-2xl font-display font-bold text-brand-yellow mt-1">{newLeads}</p>
        </div>
      </div>

      {successMsg && (
        <div className="flex items-center gap-2 rounded-lg bg-emerald-500/15 border border-emerald-500/20 p-2.5 text-xs text-emerald-400 font-mono">
          <CheckCircle2 className="h-4 w-4" />
          {successMsg}
        </div>
      )}

      {error && (
        <div className="rounded-lg bg-red-400/10 border border-red-500/20 p-2.5 text-xs text-red-400 font-mono">
          {error}
        </div>
      )}

      {/* Leads Table Container */}
      <div className="overflow-x-auto rounded-xl border border-white/10 bg-brand-blue">
        <table className="w-full text-left text-xs font-sans border-collapse">
          <thead>
            <tr className="border-b border-white/10 bg-white/5 text-[10px] font-mono uppercase tracking-wider text-gray-400">
              <th className="px-4 py-3.5">Student Info</th>
              <th className="px-4 py-3.5">Target Campus</th>
              <th className="px-4 py-3.5">Stay details</th>
              <th className="px-4 py-3.5">Status</th>
              <th className="px-4 py-3.5">Advisor Follow-up Notes</th>
              <th className="px-4 py-3.5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {leads.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-4 py-12 text-center text-gray-400 font-mono">
                  {loading ? "Syncing data, please wait..." : "No bookings submitted yet. Leads will automatically appear here."}
                </td>
              </tr>
            ) : (
              leads.map((lead) => (
                <tr key={lead.id} className="hover:bg-white/2 transition-colors">
                  {/* Name and Phone */}
                  <td className="px-4 py-4.5">
                    <p className="font-semibold text-white text-sm">{lead.name}</p>
                    <p className="text-gray-400 font-mono mt-0.5">{lead.phone}</p>
                    <span className="text-[9px] font-mono text-gray-500 uppercase block mt-1">
                      {new Date(lead.createdAt).toLocaleString([], { dateStyle: "short", timeStyle: "short" })}
                    </span>
                  </td>

                  {/* University */}
                  <td className="px-4 py-4.5 font-medium text-gray-200">
                    {lead.university}
                  </td>

                  {/* Stay Package */}
                  <td className="px-4 py-4.5 text-brand-yellow font-mono text-[11px]">
                    {lead.preferredStay}
                  </td>

                  {/* Status selection widget */}
                  <td className="px-4 py-4.5">
                    <select
                      value={lead.status}
                      onChange={(e) => handleUpdateStatus(lead.id, e.target.value)}
                      className={`rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase border focus:outline-none appearance-none cursor-pointer pr-6 relative bg-no-repeat bg-right ${
                        lead.status === "Booked"
                          ? "bg-emerald-500/15 border-emerald-500/40 text-emerald-400"
                          : lead.status === "Contacted"
                          ? "bg-blue-500/15 border-blue-500/40 text-blue-400"
                          : lead.status === "Cancelled"
                          ? "bg-gray-500/15 border-gray-500/40 text-gray-400"
                          : "bg-yellow-500/15 border-yellow-500/40 text-yellow-400"
                      }`}
                    >
                      <option value="New" className="bg-brand-blue-light text-white">New</option>
                      <option value="Contacted" className="bg-brand-blue-light text-white">Contacted</option>
                      <option value="Booked" className="bg-brand-blue-light text-white">Booked</option>
                      <option value="Cancelled" className="bg-brand-blue-light text-white">Cancelled</option>
                    </select>
                  </td>

                  {/* Follow-up Notes management inline wrapper */}
                  <td className="px-4 py-4.5 max-w-[260px]">
                    {editingNotesId === lead.id ? (
                      <div className="flex items-center gap-1.5">
                        <input
                          type="text"
                          value={editingNotesText}
                          onChange={(e) => setEditingNotesText(e.target.value)}
                          className="bg-black/40 text-xs text-white rounded px-2 py-1 border border-white/20 focus:outline-none focus:border-brand-yellow flex-1"
                          placeholder="e.g., Parent called..."
                          autoFocus
                        />
                        <button
                          onClick={() => handleSaveNotes(lead.id)}
                          className="p-1 rounded bg-brand-yellow text-brand-blue hover:bg-brand-yellow-hover"
                          title="Save notes"
                        >
                          <Save className="h-3 w-3" />
                        </button>
                      </div>
                    ) : (
                      <div
                        onClick={() => handleStartEditingNotes(lead)}
                        className="text-gray-300 hover:text-white cursor-pointer min-h-[22px] hover:bg-white/5 p-1 rounded transition-colors text-xs"
                        title="Click to edit/add advisory follow-up notes"
                      >
                        {lead.notes ? (
                          <span className="italic">{lead.notes}</span>
                        ) : (
                          <span className="text-gray-500 italic text-[11px]">+ Add follow-up comment</span>
                        )}
                      </div>
                    )}
                  </td>

                  {/* Delete trigger */}
                  <td className="px-4 py-4.5 text-right">
                    <button
                      onClick={() => handleDeleteLead(lead.id)}
                      className="p-1.5 rounded-lg text-gray-500 hover:text-red-400 hover:bg-red-500/10 transition-colors cursor-pointer"
                      title="Delete inquiry"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
