import React, { useState } from "react";
import { SharingLevel } from "../types";
import { Check, Flame, Award, Building, Sparkles, HelpCircle } from "lucide-react";

interface InteractiveCalculatorProps {
  onPreSelectConfig: (config: {
    roomType: string;
    preferredStay: string;
    finalPrice: number;
  }) => void;
}

export default function InteractiveCalculator({ onPreSelectConfig }: InteractiveCalculatorProps) {
  const [sharing, setSharing] = useState<SharingLevel>("Double");
  const [acEnabled, setAcEnabled] = useState(true);
  const [fridgeEnabled, setFridgeEnabled] = useState(false);
  const [balconyEnabled, setBalconyEnabled] = useState(false);
  const [plan, setPlan] = useState<"Monthly" | "Annual" | "Degree">("Degree");

  // Base prices
  const basePrice = sharing === "Single" ? 18000 : sharing === "Double" ? 12000 : 9000;
  
  // Custom add-ons
  const acAddon = acEnabled ? 1500 : 0;
  const fridgeAddon = fridgeEnabled ? 500 : 0;
  const balconyAddon = balconyEnabled ? 1000 : 0;

  const rawSubtotal = basePrice + acAddon + fridgeAddon + balconyAddon;

  // Discounts
  let discountPercent = 0;
  let label = "Standard Plan";
  if (plan === "Annual") {
    discountPercent = 5;
    label = "Academic Year Deal (5% off)";
  } else if (plan === "Degree") {
    discountPercent = 10;
    label = "4-Year Locked Price (10% off)";
  }

  const discountAmount = Math.round((rawSubtotal * discountPercent) / 100);
  const finalPrice = rawSubtotal - discountAmount;

  const handleApplyToForm = () => {
    const formatRoom = `${sharing} Sharing Room ${acEnabled ? "with AC" : ""}`;
    const formatPlan = plan === "Degree" ? "4 Years locked" : plan === "Annual" ? "10 Months Pack" : "Monthly Stay Pack";
    onPreSelectConfig({
      roomType: formatRoom,
      preferredStay: formatPlan,
      finalPrice: finalPrice
    });
  };

  return (
    <div className="rounded-2xl border border-white/10 bg-brand-blue-light/50 p-6 md:p-8 shadow-xl backdrop-blur-md">
      <div className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-brand-yellow/15 px-3 py-1 font-mono text-xs font-semibold text-brand-yellow">
            <Sparkles className="h-3.5 w-3.5" /> Est. Cost Configurator
          </span>
          <h3 className="font-display text-2xl font-bold text-white mt-1.5">Configure Stay Rates</h3>
        </div>
        <div className="text-left md:text-right">
          <p className="text-xs text-gray-400 font-mono">ALL-INCLUSIVE UTILITIES</p>
          <p className="text-xs text-brand-yellow font-medium mt-0.5">Includes Shuttle + 4 meals + Wi-Fi + Laundry</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Settings options */}
        <div className="lg:col-span-7 space-y-6">
          {/* Sharing configuration */}
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-gray-400 font-mono block mb-2.5">
              1. Choose Sharing Type
            </label>
            <div className="grid grid-cols-3 gap-3">
              {(["Single", "Double", "Triple"] as SharingLevel[]).map((level) => (
                <button
                  key={level}
                  onClick={() => setSharing(level)}
                  className={`relative rounded-xl border p-3.5 text-center transition-all cursor-pointer ${
                    sharing === level
                      ? "border-brand-yellow bg-brand-yellow/10 text-brand-yellow"
                      : "border-white/10 bg-black/20 text-gray-400 hover:border-white/20 hover:text-white"
                  }`}
                >
                  <p className="font-display font-semibold text-sm">{level} Share</p>
                  <p className="text-[10px] font-mono mt-1 opacity-80">
                    Hostel Suite
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Add-on amenities config */}
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-gray-400 font-mono block mb-3">
              2. Room Add-Ons
            </label>
            <div className="space-y-2.5">
              {/* AC Check */}
              <button
                onClick={() => setAcEnabled(!acEnabled)}
                className={`flex w-full items-center justify-between rounded-xl border px-4 py-3 text-left transition-all text-xs cursor-pointer ${
                  acEnabled
                    ? "border-brand-yellow bg-brand-yellow/5 text-white"
                    : "border-white/5 bg-black/10 text-gray-400 hover:border-white/10"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`flex h-5 w-5 items-center justify-center rounded-md border ${acEnabled ? "border-brand-yellow bg-brand-yellow text-brand-blue" : "border-gray-600"}`}>
                    {acEnabled && <Check className="h-3.5 w-3.5 stroke-[3]" />}
                  </div>
                  <div>
                    <p className="font-medium text-white text-sm">Room Split AC (Cooling Control)</p>
                    <p className="text-gray-400 text-[11px] mt-0.5">Dual vents, remote speed control</p>
                  </div>
                </div>
                <span className="font-mono text-brand-yellow font-semibold">+₹1,500/m</span>
              </button>

              {/* Fridge Check */}
              <button
                onClick={() => setFridgeEnabled(!fridgeEnabled)}
                className={`flex w-full items-center justify-between rounded-xl border px-4 py-3 text-left transition-all text-xs cursor-pointer ${
                  fridgeEnabled
                    ? "border-brand-yellow bg-brand-yellow/5 text-white"
                    : "border-white/5 bg-black/10 text-gray-400 hover:border-white/10"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`flex h-5 w-5 items-center justify-center rounded-md border ${fridgeEnabled ? "border-brand-yellow bg-brand-yellow text-brand-blue" : "border-gray-600"}`}>
                    {fridgeEnabled && <Check className="h-3.5 w-3.5 stroke-[3]" />}
                  </div>
                  <div>
                    <p className="font-medium text-white text-sm">Personal Mini-Fridge</p>
                    <p className="text-gray-400 text-[11px] mt-0.5">For cold juices, snacks, medicines</p>
                  </div>
                </div>
                <span className="font-mono text-brand-yellow font-semibold">+₹500/m</span>
              </button>

              {/* Balcony Check */}
              <button
                onClick={() => setBalconyEnabled(!balconyEnabled)}
                className={`flex w-full items-center justify-between rounded-xl border px-4 py-3 text-left transition-all text-xs cursor-pointer ${
                  balconyEnabled
                    ? "border-brand-yellow bg-brand-yellow/5 text-white"
                    : "border-white/5 bg-black/10 text-gray-400 hover:border-white/10"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`flex h-5 w-5 items-center justify-center rounded-md border ${balconyEnabled ? "border-brand-yellow bg-brand-yellow text-brand-blue" : "border-gray-600"}`}>
                    {balconyEnabled && <Check className="h-3.5 w-3.5 stroke-[3]" />}
                  </div>
                  <div>
                    <p className="font-medium text-white text-sm">Private Attached Balcony Wing</p>
                    <p className="text-gray-400 text-[11px] mt-0.5">Spacious outdoor view and cross breezes</p>
                  </div>
                </div>
                <span className="font-mono text-brand-yellow font-semibold">+₹1,000/m</span>
              </button>
            </div>
          </div>

          {/* Stay Package type selection */}
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-gray-400 font-mono block mb-2.5">
              3. Choose Stay Duration Pack
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                { key: "Monthly", title: "Monthly Pack", desc: "No Commitment", bonus: "Standard Rate" },
                { key: "Annual", title: "10 Months Pack", desc: "One Academic Year", bonus: "5% Direct Discount" },
                { key: "Degree", title: "Degree-Stay Plan", desc: "4 Years Locked Price", bonus: "10% Off + Rent-Lock" }
              ].map((item) => (
                <button
                  key={item.key}
                  onClick={() => setPlan(item.key as any)}
                  className={`rounded-xl border p-3 text-left transition-all relative cursor-pointer ${
                    plan === item.key
                      ? "border-brand-yellow bg-brand-yellow/10 text-white"
                      : "border-white/10 bg-black/20 text-gray-400 hover:border-white/20 hover:text-white"
                  }`}
                >
                  <div className="flex flex-col h-full justify-between">
                    <div>
                      <p className="font-semibold text-xs text-white">{item.title}</p>
                      <p className="text-[10px] text-gray-400 mt-0.5">{item.desc}</p>
                    </div>
                    <span className="mt-2.5 block text-[9px] font-mono text-brand-yellow font-medium">
                      {item.bonus}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Dynamic Pricing Summary Card */}
        <div className="lg:col-span-5 flex flex-col justify-between rounded-xl bg-brand-blue border border-white/10 p-5 text-white">
          <div className="space-y-5">
            <p className="text-xs font-semibold uppercase tracking-wider text-brand-yellow font-mono text-center bg-brand-yellow/10 py-1.5 rounded-lg">
              🎯 YOUR TAILORED MONTHLY PACKAGE
            </p>

            <div className="space-y-2 text-xs font-mono">
              <div className="flex justify-between text-gray-400 border-b border-white/5 pb-2">
                <span>Base share price ({sharing}):</span>
                <span className="text-white font-semibold">₹{basePrice.toLocaleString()}/m</span>
              </div>
              
              <div className="flex justify-between text-gray-400 pt-0.5">
                <span>Add-ons ({[acEnabled ? "AC" : null, fridgeEnabled ? "Fridge" : null, balconyEnabled ? "Balcony" : null].filter(Boolean).join(", ") || "None"}):</span>
                <span className="text-white font-semibold">
                  +₹{(acAddon + fridgeAddon + balconyAddon).toLocaleString()}/m
                </span>
              </div>

              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-400 pt-1">
                  <span>Discount ({label}):</span>
                  <span>-₹{discountAmount.toLocaleString()}/m</span>
                </div>
              )}
            </div>

            <div className="border-t border-white/10 pt-4 text-center">
              <span className="text-[10px] uppercase font-mono tracking-widest text-gray-400">Total Monthly Fee</span>
              <div className="flex items-baseline justify-center gap-1.5 mt-1">
                <span className="text-4xl font-display font-extrabold text-brand-yellow">
                  ₹{finalPrice.toLocaleString()}
                </span>
                <span className="text-xs text-gray-400 font-mono">/ Month</span>
              </div>
              <p className="text-[10px] text-gray-500 font-mono mt-1">
                *Tolls & GST inclusive. Safe refundable security deposit extra.
              </p>
            </div>
          </div>

          <div className="mt-6 space-y-3">
            <button
              onClick={handleApplyToForm}
              className="w-full rounded-xl bg-brand-yellow py-3 text-center font-display font-bold text-xs text-brand-blue hover:bg-brand-yellow-hover focus:outline-none transition-all cursor-pointer shadow-lg shadow-brand-yellow/10 duration-200"
            >
              Apply Config & Auto-Fill Offer
            </button>
            <div className="flex items-center justify-center gap-1.5 text-[10px] text-gray-400 font-mono">
              <Award className="h-3.5 w-3.5 text-brand-yellow" />
              Locked Rates guarantee for chosen duration
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
