export interface Lead {
  id: string;
  name: string;
  phone: string;
  university: string;
  preferredStay: string;
  status: "New" | "Contacted" | "Booked" | "Cancelled";
  notes?: string;
  createdAt: string;
}

export type SharingLevel = "Single" | "Double" | "Triple";

export interface RoomOption {
  id: string;
  name: string;
  sharingLevel: SharingLevel;
  pricePerMonth: number;
  image: string;
  tagline: string;
  description: string;
  features: string[];
}

export interface Amenity {
  id: string;
  name: string;
  category: "Essential" | "Hygie-Wellness" | "Premium-Lifestyle";
  iconName: string;
  description: string;
}

export interface Testimonial {
  id: string;
  author: string;
  role: "Student" | "Parent";
  relationDetails: string; // e.g. "Amity Year 2" or "Parent of GITAM CSE Student"
  quote: string;
  rating: number;
  avatar: string;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: "Location" | "Amenities" | "Billing" | "Parent Comfort";
}

export interface University {
  name: string;
  distanceKm: number;
  autoMinutes: number;
  walkMinutes: number;
  logoUrl: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "model";
  text: string;
  timestamp: string;
}
